
const router = require("express").Router();
const Property = require("../models/Property");

// Add Property
router.post("/add", async (req, res) => {
  const property = new Property(req.body);
  await property.save();
  res.json({ message: "Property Added Successfully" });
});

// Get All Properties
router.get("/", async (req, res) => {
  const properties = await Property.find().populate("owner", "name email");
  res.json(properties);
});

module.exports = router;
